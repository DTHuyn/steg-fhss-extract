import random

# Sinh dãy nhảy tần ngẫu nhiên
def generate_hopping_pattern(bit_length, secret_key, hop_range=(1, 5)):
    random.seed(secret_key)  # Đảm bảo tái lập với cùng khóa
    return [random.randint(*hop_range) for _ in range(bit_length)]

# Lưu dãy nhảy tần vào file
def save_hopping_pattern(hopping_pattern, output_file):
    with open(output_file, 'w') as f:
        f.write(' '.join(map(str, hopping_pattern)))

# Thực thi
if __name__ == "__main__":
    try:
        bit_length = int(input("Nhập số bit của dãy nhảy tần: "))
        if bit_length <= 0:
            raise ValueError("Số bit phải là số nguyên dương")
    except ValueError:
        print("Lỗi: Vui lòng nhập một số nguyên dương")
        exit(1)

    secret_key = input("Nhập khóa bí mật: ")
    if not secret_key.strip():
        print("Lỗi: Khóa bí mật không được để trống")
        exit(1)

    hopping_pattern = generate_hopping_pattern(bit_length, secret_key)
    output_file = "hopping_pattern.txt"
    save_hopping_pattern(hopping_pattern, output_file)
    print(f"Dãy nhảy tần đã được lưu vào {output_file}")
